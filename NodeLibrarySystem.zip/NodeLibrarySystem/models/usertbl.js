// UserId(PK), FirstName, Gender, BirthDay, Phone, Address

"use strict";

const mongoose = require("mongoose"),
  { Schema } = require("mongoose");

var userSchema = new Schema(
  {
    FirstName: {
      type: String,
      required: true
    },
    Gender: {
      type: String
    },
    BirthDay: {
        type: String
    },
    Phone: {
        type: String
      },
    Address: {
        type: String
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("usertbls", userSchema); //use User for controller
