// BookId(PK), Status, LendDate, ReturnDate, UserID
"use strict";

const mongoose = require("mongoose"),
  { Schema } = require("mongoose");

var lendSchema = new Schema(
  {
    Status: {
      type: String,
      required: true
    },
    LendDate: {
      type: String
    },
    ReturnDate: {
        type: String
    },
    bookID: { type: Schema.Types.ObjectId, ref: "Book" },
    UserID: { type: Schema.Types.ObjectId, ref: "User" }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("lendtbls", lendSchema); //use Lend for controller
