// BookId(PK), BookTitle, AuthorName, Classification, Description

"use strict";

const mongoose = require("mongoose"),
  { Schema } = require("mongoose");

var bookSchema = new Schema(
  {
    BookTitle: {
      type: String,
      required: true
    },
    AuthorName: {
      type: String,
      required: true
    },
    Classification: {
        type: String,
        required: true
      },
      Description: {
        type: String
      }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("booktbls", bookSchema); //use Book for controller
