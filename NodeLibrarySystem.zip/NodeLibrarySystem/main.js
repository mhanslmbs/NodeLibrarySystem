// insert data for mongo db. with Repl.js(record 3 books and 3 subscribers )
// try to complete main.js, look at lesson 21 for reference. 
// Run and debug lesson 21 various times.
// contruct controllers.


"use strict";

const express = require("express"),
  layouts = require("express-ejs-layouts"),
  app = express(),
  router = express.Router(),
 homeController = require("./controllers/homeController"),
  errorController = require("./controllers/errorController"),
  userController = require("./controllers/userController.js"),
  bookController = require("./controllers/bookController.js"),
  lendController = require("./controllers/lendController.js"),
  mongoose = require("mongoose"),
  methodOverride = require("method-override");

mongoose.connect(
  "mongodb://localhost:27017/LibraryDB",
  { useNewUrlParser: true }
);

mongoose.set("useCreateIndex", true);

app.set("port", process.env.PORT || 3000);
app.set("view engine", "ejs");


router.use(
  methodOverride("_method", {
    methods: ["POST", "GET"]
  })
);

router.use(layouts);
router.use(express.static("public"));

router.use(
  express.urlencoded({
    extended: false
  })
);
router.use(express.json());
router.use(display_url_method);

router.get("/", homeController.index);


router.get("/user", userController.index, userController.indexView);//display user list
router.get("/user/new", userController.new);// input user for insert
router.post("/user/create", userController.create, userController.redirectView);//insert user
router.get("/user/:id/edit", userController.edit);//input user for edit
router.put("/user/:id/update", userController.update, userController.redirectView);//update user
router.get("/user/:id", userController.show, userController.showView);//display a user
router.delete("/user/:id/delete", userController.delete, userController.redirectView);// delete the user
router.get("/user/lend/:bookid/show", lendController.show, lendController.showView);//Display the book lent by user
router.get("/user/lend/:id", userController.lendIndex, lendController.lendView);//display list of books for returning


router.get("/lend/:id", lendController.index, lendController.indexView);//display list of books for lending
router.get("/lend/:bookid/:userid/new", lendController.new, lendController.redirectView);//insert lend data 
router.get("/lend/:bookid/show", lendController.show, lendController.showView);//display lending information
router.get("/lend/:lendid/delete", lendController.delete, lendController.redirectView);//Delete lend data 


router.get("/book", bookController.index, bookController.indexView);//display book list
router.get("/book/new", bookController.new);//input book for insert
router.post("/book/create", bookController.create, bookController.redirectView);//insert book
router.get("/book/:id/edit", bookController.edit);//input book for edit
router.put("/book/:id/update", bookController.update, bookController.redirectView);//update book
router.get("/book/:id", bookController.show, bookController.showView);//display a book
 router.delete("/book/:id/delete", bookController.delete, bookController.redirectView);//delete the book


router.use(errorController.pageNotFoundError);
router.use(errorController.internalServerError);

app.use("/", router);

app.listen(app.get("port"), () => {
  console.log(`Server running at http://localhost:${app.get("port")}`);
});

function display_url_method(req, res,next) {
  console.log("method:"+req.method +"   path:"+req.path);
  next();
}