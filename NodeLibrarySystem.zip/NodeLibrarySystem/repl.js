const mongoose = require("mongoose"),
  UserTbl = require("./models/usertbl")
  BookTbl = require("./models/booktbl")
  LendTbl = require("./models/lendtbl")
 
var  testUserTbl;
mongoose.connect(
  "mongodb://localhost:27017/LibraryDB",
  { useNewUrlParser: true }
);
mongoose.set("useCreateIndex", true);
mongoose.Promise = global.Promise;
UserTbl.remove({})
  .then(items => console.log(`Removed ${items.n} records!`))
  .then(() => {
    return BookTbl.remove({});
  })
  .then(items => console.log(`Removed ${items.n} records!`))
  .then(() => {
    return LendTbl.remove({});
  })
  .then(items => console.log(`Removed ${items.n} records!`))
  .then(() => {
    return UserTbl.create({
      FirstName: "Carl Bailey",
      Gender: "Male",
      BirthDay: "2000-03-30",
      Phone: "001-1234-1111",
      Address: "3Ave Redmond, WA 98052-7329 USA"
    });
  })
  .then(() => {
    return UserTbl.create({
      FirstName: "Georgia Obrien",
      Gender: "Female",
      BirthDay: "2000-04-30",
      Phone: "001-1234-2222",
      Address: "4Ave Redmond, WA 98052-7329 USA"
    });
  })  
  .then(() => {
    return UserTbl.create({
      FirstName: "Wade Carlson",
      Gender: "Male",
      BirthDay: "2000-05-30",
      Phone: "001-1234-3333",
      Address: "5Ave Redmond, WA 98052-7329 USA"
    });
  })
  .then(() => {
    return UserTbl.create({
      FirstName: "Marcia Stanley",
      Gender: "Female",
      BirthDay: "2000-06-30",
      Phone: "001-1234-4444",
      Address: "6Ave Redmond, WA 98052-7329 USA"
    });
  })  
  .then(() => {
    return BookTbl.create({
      BookTitle: "3rd Grade FSA Math Workbook 2018",
      AuthorName: "Reza Nazari,Ava Ross",
      Classification: "Mathematics",
      Description: "The Book Ever Need to ACE the FSA Math Exam!",
    });
  })
  .then(() => {
    return BookTbl.create({
      BookTitle: "ASVAB Math for Beginners",
      AuthorName: "Reza Nazari",
      Classification: "Mathematics",
      Description: "The Book for ASVAB Math Exam!.",
    });
  })
  .then(() => {
    return BookTbl.create({
      BookTitle: " Pro iOS Geo",
      AuthorName: "Giacomo Andreucci",
      Classification: "Geography",
      Description: "Development skills with Pro iOS Geo.",
    });
  })
  .then(() => {
    return BookTbl.create({
      BookTitle: "Marine Insurance",
      AuthorName: "Merkin, Rob",
      Classification: "Geography",
      Description: "A comprehensive examination of marine insurance",
    });
  })
  .then(() => process.exit());
