"use strict";

const bookTbl = require("../models/booktbl");
const lendTbl = require("../models/lendtbl");

const  getUserParams = body => {
    return {
      BookTitle: body.BookTitle,
      AuthorName: body.AuthorName,
      Classification: body.Classification,
      Description: body.Description,
    };
  };

module.exports = {
  index: (req, res, next) => {
    let isDone=false; 
    bookTbl.find()
      .then(book => {
        let tCount=0;
        let Count=0;
        book.forEach((elem, index) => {
          lendTbl.find({bookID:elem._id})
        .then(lends => {
          if(lends.length>0){
            elem.Status="No";
            Count++;
          }else{
            elem.Status="Yes";
          }
          tCount++;
          if(tCount==book.length){
            res.locals.book = book;
            res.locals.Count = Count;
            res.locals.userid = req.params.id;
            next();
          }
        })
        .catch(error => {
          console.log(`Error fetching users: ${error.message}`);
          next(error);
        });
      }); 
    })
      .catch(error => {
        console.log(`Error fetching book: ${error.message}`);
        next(error);
      });
  },

  indexView: (req, res) => {
    res.render("book/index");
  },

  new: (req, res) => {
    res.render("book/new");
  },

  create: (req, res, next) => {
    let bookParams = getUserParams(req.body);

    bookTbl.create(bookParams)
      .then(book => {
        res.locals.redirect = "/book";
        res.locals.book = book;
        next();
      })
      .catch(error => {
        console.log(`Error saving book: ${error.message}`);
        next(error);
      });
  },

  redirectView: (req, res, next) => {
    let redirectPath = res.locals.redirect;
    if (redirectPath !== undefined) res.redirect(redirectPath);
    else next();
  },

  show: (req, res, next) => {
    let bookId = req.params.id;
    bookTbl.findById(bookId)
      .then(book => {
        res.locals.book = book;
        next();
      })
      .catch(error => {
        console.log(`Error fetching book by ID: ${error.message}`);
        next(error);
      });
  },

  showView: (req, res) => {
    res.render("book/show");
  },

  edit: (req, res, next) => {
    let bookId = req.params.id;
    bookTbl.findById(bookId)
      .then(book => {
        res.render("book/edit", {
          book: book
        });
      })
      .catch(error => {
        console.log(`Error fetching book by ID: ${error.message}`);
        next(error);
      });
  },

  update: (req, res, next) => {
    let bookId = req.params.id,
      bookParams = getUserParams(req.body);

    bookTbl.findByIdAndUpdate(bookId, {
      $set: bookParams
    })
      .then(book => {
        res.locals.redirect = `/book/${bookId}`;
        res.locals.book = book;
        next();
      })
      .catch(error => {
        console.log(`Error updating book by ID: ${error.message}`);
        next(error);
      });
  },

  delete: (req, res, next) => {
    let bookId = req.params.id;
    
    bookTbl.findByIdAndRemove(bookId)
      .then(() => {
        res.locals.redirect = "/book";
        next();
      })
      .catch(error => {
        console.log(`Error deleting book by ID: ${error.message}`);
        next();
      });
  }
};
