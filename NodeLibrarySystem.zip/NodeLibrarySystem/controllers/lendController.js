const bookTbl = require("../models/booktbl");
const lendTbl = require("../models/lendtbl");

function formatDate(dt) {
  var y = dt.getFullYear();
  var m = ('00' + (dt.getMonth()+1)).slice(-2);
  var d = ('00' + dt.getDate()).slice(-2);
  return (y + '-' + m + '-' + d);
}


getLendParams = param => {
    return {
        Status: "Yes",
        LendDate: formatDate(new Date()),
        ReturnDate: null,
        bookID: param.bookid,
        UserID: param.userid
    };
  };

  module.exports = {

    index: (req, res, next) => {
      let isDone=false; 
      bookTbl.find()
        .then(book => {
          let tCount=0;
          book.forEach((elem, index) => {
            lendTbl.find({bookID:elem._id})
          .then(lends => {
            if(lends.length>0){
              elem.Status="No";
            }else{
              elem.Status="Yes";
            }
            tCount++;
            if(tCount==book.length){
              res.locals.book = book;
              res.locals.userid = req.params.id;
              next();
            }
          })
          .catch(error => {
            console.log(`Error fetching users: ${error.message}`);
            next(error);
          });
        }); 
      })
        .catch(error => {
          console.log(`Error fetching book: ${error.message}`);
          next(error);
        });
    },
  
    indexView: (req, res) => {
      res.render("lend/index");
    },
  
  
    redirectView: (req, res, next) => {
      let redirectPath = res.locals.redirect;
      if (redirectPath !== undefined) res.redirect(redirectPath);
      else next();
    },
  
    show: (req, res, next) => {
      let bookid = req.params.bookid;
      lendTbl.find({bookID:bookid})
        .then(lend => {
          res.locals.lend = lend;
          next();
        })
        .catch(error => {
          console.log(`Error fetching book by ID: ${error.message}`);
          next(error);
        });
    },
  
    showView: (req, res) => {
      res.render("lend/show");
    },
    
    new: (req, res, next) => {
        let userId = req.params.userid;
        let bookId = req.params.bookid;
        let lendParams = getLendParams(req.params);

        lendTbl.create(lendParams)
          .then(lend => {
            res.locals.redirect = "/lend/"+userId;
            res.locals.lend = lend;
            next();
          })
          .catch(error => {
            console.log(`Error saving: ${error.message}`);
            next(error);
          });
      },

      delete: (req, res, next) => {
        let lendId = req.params.lendid;
        lendTbl.findByIdAndRemove(lendId)
          .then(() => {
            res.locals.redirect = "/";
            next();
          })
          .catch(error => {
            console.log(`Error deleting lend by ID: ${error.message}`);
            next();
          });
      },


      lendView: (req, res) => {
        res.render("user/lendIndex");
      },

  };