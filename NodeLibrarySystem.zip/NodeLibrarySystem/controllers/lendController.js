const bookTbl = require("../models/booktbl");
const userTbl = require("../models/usertbl");
const lendTbl = require("../models/lendtbl");

function formatDate(dt) {
  var y = dt.getFullYear();
  var m = ('00' + (dt.getMonth()+1)).slice(-2);
  var d = ('00' + dt.getDate()).slice(-2);
  return (y + '-' + m + '-' + d);
}


getLendParams = param => {
    return {
        Status: "Yes",
        LendDate: formatDate(new Date()),
        ReturnDate: null,
        bookID: param.bookid,
        UserID: param.userid
    };
  };

  const  getBookParams = body => {
    return {
      BookTitle: body.TitleSearch,
      AuthorName: body.AuthorSearch,
      Classification: body.ClassificationSearch,
    };
  };

  module.exports = {

    index: (req, res, next) => {
      let isDone=false; 
      bookTbl.find()
        .then(book => {
          let tCount=0;
          book.forEach((elem, index) => {
            lendTbl.find({bookID:elem._id})
          .then(lends => {
            if(lends.length>0){
              elem.Status="No";
            }else{
              elem.Status="Yes";
            }
            tCount++;
            if(tCount==book.length){
              userTbl.findById(req.params.id)
                .then(user=>{
                  res.locals.userName = user.FirstName;
                  res.locals.bookParams = {};
                  res.locals.book = book;
                  res.locals.userid = req.params.id;
                  next();
                  })
              // res.locals.book = book;
              // res.locals.userid = req.params.id;
              // next();
            }
          })
          .catch(error => {
            console.log(`Error fetching users: ${error.message}`);
            next(error);
          });
        }); 
      })
        .catch(error => {
          console.log(`Error fetching book: ${error.message}`);
          next(error);
        });
    },
  
    indexView: (req, res) => {
      res.render("lend/index");
    },
  
  
    redirectView: (req, res, next) => {
      let redirectPath = res.locals.redirect;
      if (redirectPath !== undefined) res.redirect(redirectPath);
      else next();
    },
  
    show: (req, res, next) => {
      let bookid = req.params.bookid;
      lendTbl.findOne({bookID:bookid})
        .then(lend => {
          userTbl.findById(lend.UserID)
          .then(user => {

              lend.username= user.FirstName;
              bookTbl.findById(lend.bookID)
                .then(book => {
      
                    lend.booktitle= book.BookTitle;
                    res.locals.lend = lend;
                    next();
                  
              })
            

          })
        })
        .catch(error => {
          console.log(`Error fetching book by ID: ${error.message}`);
          next(error);
        });
    },
  
    showView: (req, res) => {
      res.render("lend/show");
    },
    
    new: (req, res, next) => {
        let userId = req.params.userid;
        let bookId = req.params.bookid;
        let lendParams = getLendParams(req.params);

        lendTbl.create(lendParams)
          .then(lend => {
            res.locals.redirect = "/lend/"+userId;
            res.locals.lend = lend;
            next();
          })
          .catch(error => {
            console.log(`Error saving: ${error.message}`);
            next(error);
          });
      },

      delete: (req, res, next) => {
        let lendId = req.params.lendid;
        lendTbl.findByIdAndRemove(lendId)
          .then(() => {
            res.locals.redirect = "/";
            next();
          })
          .catch(error => {
            console.log(`Error deleting lend by ID: ${error.message}`);
            next();
          });
      },


      lendView: (req, res) => {
        res.render("user/lendIndex");
      },

      search: (req, res, next) => {

        let bookParams = getBookParams(req.body);

        let titleRegex = new RegExp(bookParams.BookTitle);
        let authorRegex = new RegExp(bookParams.AuthorName);
        let classRegex = new RegExp(bookParams.Classification);
        

        bookTbl.find({
        BookTitle:{$regex:titleRegex , $options: '-i'},
        AuthorName:{$regex:authorRegex , $options: '-i'},
        Classification:{$regex:classRegex , $options: '-i'}
        })
          .then(book => {
            if(book.length===0){
                  res.locals.userName = "";
                  res.locals.book = [];
                  res.locals.userid = req.params.id;
                  res.locals.bookParams = bookParams;
                  next();
            }
            let tCount=0;
            book.forEach((elem, index) => {

              lendTbl.find({bookID:elem._id})
            .then(lends => {
              if(lends.length>0){
                elem.Status="No";
              }else{
                elem.Status="Yes";
              }
              tCount++;
              if(tCount==book.length){
                userTbl.findById(req.params.id)
                .then(user=>{
                  res.locals.userName = user.FirstName;
                  res.locals.bookParams = bookParams;
                  res.locals.book = book;
                  res.locals.userid = req.params.id;
                  next();
                  })
                // res.locals.book = book;
                // res.locals.userid = req.params.id;
                // next();
              }
            })
            .catch(error => {
              console.log(`Error fetching users: ${error.message}`);
              next(error);
            });
          }); 
        })
          .catch(error => {
            console.log(`Error fetching book: ${error.message}`);
            next(error);
          });
      },

  };