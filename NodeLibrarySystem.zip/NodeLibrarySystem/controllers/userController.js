"use strict";

const userTbl = require("../models/usertbl");
const lendTbl = require("../models/lendtbl");
const bookTbl = require("../models/booktbl");

const  getUserParams = body => {
    return {
      FirstName: body.FirstName,
      Gender: body.Gender,
      BirthDay: body.BirthDay,
      Phone: body.Phone,
      Address: body.Address
    };
  };

module.exports = {
  index: (req, res, next) => {
    let userId = req.params.id;
    userTbl.find()
   .then(user => {
        let tCount=0;
        let Count=0;
        user.forEach((elem, index) => {
          lendTbl.find({UserID:elem._id})
        .then(lends => {
          elem.Count = lends.length;
          tCount++;
          if(tCount==user.length){
            res.locals.user = user;
            res.locals.userid = req.params.id;
            next();
          }
        })
        .catch(error => {
          console.log(`Error fetching users: ${error.message}`);
          next(error);
        });
      }); 
    })
      .catch(error => {
        console.log(`Error fetching user: ${error.message}`);
        next(error);
      });
  },
  indexView: (req, res) => {
    res.render("user/index");
  },

  new: (req, res) => {
    res.render("user/new");
  },

  create: (req, res, next) => {
    let userParams = getUserParams(req.body);

    userTbl.create(userParams)
      .then(user => {
        res.locals.redirect = "/user";
        res.locals.user = user;
        next();
      })
      .catch(error => {
        console.log(`Error saving user: ${error.message}`);
        next(error);
      });
  },

  redirectView: (req, res, next) => {
    let redirectPath = res.locals.redirect;
    if (redirectPath !== undefined) res.redirect(redirectPath);
    else next();
  },


    show: (req, res, next) => {
    let userId = req.params.id;
    let Status = "Yes";
    userTbl.findById(userId)
      .then(user => {
          lendTbl.find({UserID:userId})
        .then(lends => {
          if(lends.length>0){
            Status="Yes";
          }else{
            Status="No";
          }
            res.locals.user = user;
            res.locals.Status = Status;
            res.locals.userid = req.params.id;
            next();
        })
        .catch(error => {
          console.log(`Error fetching users: ${error.message}`);
          next(error);
        });
      })
      .catch(error => {
        console.log(`Error fetching user by ID: ${error.message}`);
        next(error);
      });
  },

  showView: (req, res) => {
    res.render("user/show");
  },

  edit: (req, res, next) => {
    let userId = req.params.id;
    userTbl.findById(userId)
      .then(user => {
        res.render("user/edit", {
          user: user
        });
      })
      .catch(error => {
        console.log(`Error fetching user by ID: ${error.message}`);
        next(error);
      });
  },

  update: (req, res, next) => {
    let userId = req.params.id,
      userParams = getUserParams(req.body);

    userTbl.findByIdAndUpdate(userId, {
      $set: userParams
    })
      .then(user => {
        res.locals.redirect = `/user/${userId}`;
        res.locals.user = user;
        next();
      })
      .catch(error => {
        console.log(`Error updating user by ID: ${error.message}`);
        next(error);
      });
  },

  delete: (req, res, next) => {
    let userId = req.params.id;
    userTbl.findByIdAndRemove(userId)
      .then(() => {
        res.locals.redirect = "/user";
        next();
      })
      .catch(error => {
        console.log(`Error deleting user by ID: ${error.message}`);
        next();
      });
  },

  lendIndex: (req, res, next) => {
    let userId = req.params.id;
    let isDone=false; 
    bookTbl.find()
      .then(book => {
        let tCount=0;
        book.forEach((elem, index) => {
          lendTbl.find({UserID:userId, bookID:elem._id})
        .then(lends => {
          if(lends.length>0){
            elem.Status="No";
          }else{
            elem.Status="Yes";
          }
          tCount++;
          if(tCount==book.length){
            res.locals.book = book;
            res.locals.userid = req.params.id;
            next();
          }
        })
        .catch(error => {
          console.log(`Error fetching users: ${error.message}`);
          next(error);
        });
      }); 
    })
      .catch(error => {
        console.log(`Error fetching book: ${error.message}`);
        next(error);
      });
  }

  
};
