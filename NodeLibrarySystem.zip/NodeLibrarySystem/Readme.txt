Requirements:
Node (v14.18.1)+
mongoDB (4.4.6) Port:27017

Preperation Steps:

1. Open cmd and change to project directory
2. Run "npm install"
3. Run "npm audit fix" (If neccecary)
4. Run "node repl.js"
5. Run "node main.js"
6. Open (http://localhost:3000) to view it in your browser.

Features:

- Display books in the DB to the app
- Display readers in the DB to the app
- Register new books and readers to the DB
- Edit existing books and readers and update DB
- Delete existing books and readers from DB
- Have readers lend books and register status to the DB
- Return books from readers and remove the status to the DB
